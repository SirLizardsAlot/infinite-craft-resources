# Digit Items Template

This pack adds a reusable item model definition at `rpe_digits:symbols`.

It is designed for 1.21.11's current item model system:

- `minecraft:custom_model_data.floats[0]` selects the number
- `minecraft:custom_model_data.colors[0]` tints the number
- `minecraft:custom_model_data.flags[0] = true` switches the item to the flag texture

All textures start as transparent 16x16 PNGs so you can draw them yourself.

## Example commands

Red `0`:

```mcfunction
/give @p paper[minecraft:item_model="rpe_digits:symbols",minecraft:custom_model_data={floats:[0],colors:[16711680]}]
```

Blue `7`:

```mcfunction
/give @p paper[minecraft:item_model="rpe_digits:symbols",minecraft:custom_model_data={floats:[7],colors:[255]}]
```

White flag:

```mcfunction
/give @p paper[minecraft:item_model="rpe_digits:symbols",minecraft:custom_model_data={flags:[true],colors:[16777215]}]
```

Mine item:

```mcfunction
/give @p paper[minecraft:item_model="rpe_digits:mine",minecraft:custom_model_data={colors:[16777215]}]
```

## Variant map

- `0` -> `number_0.png`
- `1` -> `number_1.png`
- `2` -> `number_2.png`
- `3` -> `number_3.png`
- `4` -> `number_4.png`
- `5` -> `number_5.png`
- `6` -> `number_6.png`
- `7` -> `number_7.png`
- `8` -> `number_8.png`
- `9` -> `number_9.png`
- `flags[0]=true` -> `flag.png`
- direct model `rpe_digits:mine` -> `mine.png`

## Connected outline masks

I also added 16 prebuilt connected-outline textures in:

- `assets/rpe_digits/textures/item/outlines/`

They use a `TRBL` bit mask:

- `T` = top neighbor exists
- `R` = right neighbor exists
- `B` = bottom neighbor exists
- `L` = left neighbor exists

`1` means that side has a matching neighbor.
`0` means that side is exposed, so the 1px white outline is drawn there.

Examples:

- `outline_0000.png` = fully exposed outline
- `outline_1111.png` = no outline
- `outline_1011.png` = only the right edge is exposed
- `outline_0111.png` = only the top edge is exposed

The outline textures are white on transparent background so you can tint them however you want in-game.

## Direct outline item ids

You can also target each outline directly with DF's `/i model set`.

Use one of these model ids:

- `rpe_digits:outline_0000`
- `rpe_digits:outline_0001`
- `rpe_digits:outline_0010`
- `rpe_digits:outline_0011`
- `rpe_digits:outline_0100`
- `rpe_digits:outline_0101`
- `rpe_digits:outline_0110`
- `rpe_digits:outline_0111`
- `rpe_digits:outline_1000`
- `rpe_digits:outline_1001`
- `rpe_digits:outline_1010`
- `rpe_digits:outline_1011`
- `rpe_digits:outline_1100`
- `rpe_digits:outline_1101`
- `rpe_digits:outline_1110`
- `rpe_digits:outline_1111`

They are still tintable through `custom_model_data.colors[0]`.

Example:

```mcfunction
/i model set rpe_digits:outline_1011
```

Then set:

- `color[0] = 16711680` for red
- `color[0] = 16777215` for white
- `color[0] = 255` for blue

## 8-neighbor outline ids

I also added a full 8-neighbor set in:

- `assets/rpe_digits/textures/item/outlines8/`

These use this bit order:

- `TL T TR R BR B BL L`

That means the direct model ids look like:

- `rpe_digits:outline_00000000`
- `rpe_digits:outline_10110010`
- `rpe_digits:outline_11111111`

Example:

```mcfunction
/i model set rpe_digits:outline_10110010
```

Those ids are still tintable through `custom_model_data.colors[0]`.

The 8-neighbor corner logic draws a corner pixel unless all three touching neighbors for that corner exist, so `11111111` gives no outline and `00000000` gives a full 1px border.

## InfiniteItems pixel item

I also copied the `glam` namespace from the `InfiniteItems` pack into this pack so the 256-pixel colorable item is available here too.

Direct model ids:

- `glam:glam_item`
- `glam:glam_large`
- `glam:glam_mace`
- `glam:glam_base`

The normal flat 16x16-style one is:

- `glam:glam_item`

Usage pattern:

- set the model id with `/i model set`
- use `flag[index] = true` to turn a pixel on
- use `color[index] = <rgb int>` to color that pixel

The copied item definitions suggest those indices run from `0` through `255`, one slot per pixel.
